"""BLE Remote protocol v1 (shared by Sender and Receiver).
Envelope : [len:4][crc32:4][JSON body]   body = {"id","t","d"}
Fragment : [msg:2][idx:2][total:2][payload]   (payload <= MTU-3-6)
Types    : apply_text, clear, ping (Sender->Receiver) / ack (Receiver->Sender)
Nothing is shown on Receiver unless an explicit apply_* message arrives."""
import json, struct, zlib, uuid

SERVICE = "12345678-1234-5678-1234-56789abcdef0"
WRITE_CHAR = "12345678-1234-5678-1234-56789abcdef1"   # sender -> receiver
NOTIFY_CHAR = "12345678-1234-5678-1234-56789abcdef2"  # receiver -> sender
_counter = [0]

def new_id():
    return uuid.uuid4().hex[:12]

def encode(type_, data=None, id_=None):
    body = json.dumps({"id": id_ or new_id(), "t": type_, "d": data or {}},
                      ensure_ascii=False).encode("utf-8")
    return struct.pack(">II", len(body), zlib.crc32(body) & 0xFFFFFFFF) + body

def fragment(envelope, chunk_size):
    size = max(8, chunk_size - 6)
    _counter[0] = (_counter[0] + 1) & 0xFFFF
    parts = [envelope[i:i + size] for i in range(0, len(envelope), size)] or [b""]
    return [struct.pack(">HHH", _counter[0], i, len(parts)) + p for i, p in enumerate(parts)]

class Reassembler:
    def __init__(self):
        self.buf = {}
    def feed(self, packet):
        """Returns decoded dict when a complete, valid message arrived, else None."""
        if len(packet) < 6:
            return None
        mid, idx, total = struct.unpack(">HHH", packet[:6])
        parts = self.buf.setdefault(mid, {})
        parts[idx] = packet[6:]
        if len(parts) < total:
            return None
        env = b"".join(parts[i] for i in range(total) if i in parts)
        del self.buf[mid]
        if len(env) < 8:
            return None
        ln, crc = struct.unpack(">II", env[:8])
        body = env[8:8 + ln]
        if len(body) != ln or (zlib.crc32(body) & 0xFFFFFFFF) != crc:
            return None
        try:
            return json.loads(body.decode("utf-8"))
        except Exception:
            return None

def shape(text):
    """Arabic shaping + bidi for Kivy labels."""
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return get_display(arabic_reshaper.reshape(text))
    except Exception:
        return text

def to_bytes(java_arr):
    return bytes((b & 0xFF) for b in java_arr)
